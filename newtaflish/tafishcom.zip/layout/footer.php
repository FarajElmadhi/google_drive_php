<div class="pgWrap copRightAckBg">
  <div class="container">
    <div class="copyRightAckWrap text-center clearfix">
   <p> Made With <i class="fa fa-heart"></i>
   By <a href="https://www.facebook.com/faraj.modahhy" target="_blank"> Faraj Elmadhi </a> &copy; <?php echo date('Y'); ?>  </p>
    </div>
  </div>
</div>
